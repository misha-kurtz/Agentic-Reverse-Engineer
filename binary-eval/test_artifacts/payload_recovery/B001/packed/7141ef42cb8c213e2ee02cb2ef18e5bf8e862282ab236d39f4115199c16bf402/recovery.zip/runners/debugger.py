# binary-eval/runners/debugger.py

from __future__ import annotations

import queue
import re
import struct
import subprocess
import threading
import time

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

'''
WinDbg/ConsoleDbg Interface for Automated Payload Recovery 

Purpose:
    Provide a reusable Python interface to the Windows Console Debugger
    (CDB) for controlling executable execution, inspecting process memory,
    managing breakpoints, and disassembling instructions.

    This module serves as the debugging foundation for runtime payload
    recovery, exposing debugger operations to higher-level analysis modules.

Responsibilities:
    1. Launch target executables under CDB with child-process debugging.
    2. Manage the debugger subprocess and its lifecycle.
    3. Send debugger commands and capture their output.
    4. Detect debugger prompts and enforce command timeouts.
    5. Continue execution and perform single-instruction stepping.
    6. Read individual CPU registers and register collections.
    7. Enumerate loaded modules and retrieve their memory boundaries.
    8. Install software execution and hardware memory-access breakpoints.
    9. List and clear existing debugger breakpoints.
    10. Read individual and consecutive 64-bit memory values.
    11. Dump specified process memory regions using CDB.
    12. Disassemble instructions at specified virtual addresses.
    13. Validate decoded instruction addresses, sizes, and raw bytes.
    14. Retrieve preceding instructions and iterate sequential disassembly.
    15. Resolve supported direct relative JMP destinations.
    16. Retrieve the process identifier of the active debuggee.
    17. Parse debugger output into structured Python objects.

Input:
    - Path to the CDB executable.
    - Target executable and optional command-line arguments.
    - Debugger commands and execution-control requests.
    - Virtual addresses for memory inspection and disassembly.
    - Register names, module names, and breakpoint addresses.
    - Memory boundaries and output paths for memory dumping.

Output:
    - Active debugger session with execution-control capabilities.
    - CPU register values and process information.
    - Loaded-module metadata through ModuleInfo.
    - Disassembled instructions through Instruction.
    - Direct branch information through DirectJump.
    - Raw memory values and process memory dumps.
    - Debugger command output and diagnostic errors.

Workflow:
    Receive CDB path and target executable
        |
        v
    Launch executable under CDB
        |
        v
    Initialize debugger subprocess
        |
        v
    Start asynchronous output reader
        |
        v
    Wait for initial debugger prompt
        |
        v
    Establish active debugging session
        |
        v
    Execute requested debugger operations
        |
        +-----------------------------------+
        |                 |                 |
        v                 v                 v
    Execution         Memory and        Disassembly
    Control           Registers         and Modules
        |                 |                 |
        v                 v                 v
    Continue / Step   Read / Dump       Decode / Parse
    Breakpoints       Inspect State     Validate Bytes
        |                 |                 |
        +-----------------+-----------------+
                          |
                          v
    Parse and validate debugger output
                          |
                          v
    Return structured results to calling modules
                          |
                          v
    Support runtime payload recovery operations
                          |
                          v
    Close debugger session when complete

This module provides the low-level debugging interface used by the
higher-level payload recovery components.

It does not independently discover the Original Entry Point (OEP),
identify decrypted payload boundaries, reconstruct control-flow graphs,
discover or resolve IAT entries, or rebuild executable PE structures.

Those responsibilities belong to the corresponding analysis and
reconstruction modules.

The debugger interface is independent of any specific executable
packer and can be reused across different runtime analysis workflows.
'''

class DebuggerError(RuntimeError):
    pass


@dataclass(frozen=True)
class Instruction:
    address: int
    raw_bytes: bytes
    mnemonic: str
    operands: str
    text: str

    @property
    def size(self) -> int:
        return len(self.raw_bytes)


@dataclass(frozen=True)
class ModuleInfo:
    name: str
    base: int
    end: int


@dataclass(frozen=True)
class DirectJump:
    source: int
    target: int
    size: int


class CdbDebugger:
    """
    Thin synchronous wrapper around cdb.exe.

    This class intentionally contains no UPX-specific logic.
    """

    _PROMPT_RE = re.compile(r"(?:\d+:\d+(?::[a-z0-9]+)?|[a-z]+)>\s*$", re.IGNORECASE,)

    _REGISTER_RE = re.compile(r"\b([a-z0-9]+)=([0-9a-fA-F`]+)")

    _MODULE_RE = re.compile(r"^\s*" r"([0-9a-fA-F`]+)\s+" r"([0-9a-fA-F`]+)\s+" r"(\S+)", re.MULTILINE,)

    # Typical ConsoleDbg disassembly:
    #
    # 00007ff7`93d78e90 53              push    rbx
    #
    _DISASM_RE = re.compile(
        r"^\s*"
        r"([0-9a-fA-F`]+)\s+"
        r"([0-9a-fA-F]+)\s+"
        r"([a-zA-Z][a-zA-Z0-9.]*)"
        r"(?:\s+(.*?))?"
        r"\s*$"
    )

    def __init__(
        self,
        cdb_path: Path | str,
        command_timeout: float = 30.0,
    ):
        self.cdb_path = Path(cdb_path)
        self.command_timeout = command_timeout

        self._proc: subprocess.Popen | None = None
        self._output_queue: queue.Queue[str] = queue.Queue()
        self._reader_thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def launch(
        self,
        executable: Path | str,
        arguments: list[str] | None = None,
    ) -> None:

        executable = Path(executable)
        arguments = arguments or []

        if not self.cdb_path.exists():
            raise DebuggerError(f"CDB not found: {self.cdb_path}")

        if not executable.exists():
            raise DebuggerError(f"Debug target not found: {executable}")

        command = [
            str(self.cdb_path),

            # Debug child processes as well.
            "-o",

            # Target executable.
            str(executable),

            *arguments,
        ]

        self._proc = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=0,
        )

        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True,)

        self._reader_thread.start()

        # CDB initially breaks in the loader/ntdll startup path.
        self._read_until_prompt(timeout=self.command_timeout,)

    def close(self) -> None:
        if self._proc is None:
            return

        try:
            if self._proc.poll() is None:
                self._send_raw("q\n")
                self._proc.wait(timeout=5)

        except Exception:
            self._proc.kill()

        self._proc = None

    def __enter__(self) -> "CdbDebugger":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    # ------------------------------------------------------------------
    # Command transport
    # ------------------------------------------------------------------

    def _reader_loop(self) -> None:
        assert self._proc is not None
        assert self._proc.stdout is not None

        while True:
            char = self._proc.stdout.read(1)

            if char == "":
                break

            self._output_queue.put(char)

    def _send_raw(self, text: str) -> None:
        if self._proc is None:
            raise DebuggerError("Debugger is not running")

        if self._proc.poll() is not None:
            raise DebuggerError(f"CDB exited with code " f"{self._proc.returncode}")

        assert self._proc.stdin is not None

        self._proc.stdin.write(text)
        self._proc.stdin.flush()

    def _read_until_prompt(self, timeout: float | None = None,) -> str:

        timeout = timeout or self.command_timeout
        deadline = time.monotonic() + timeout

        output: list[str] = []
        tail = ""

        while time.monotonic() < deadline:
            remaining = max(0.01, deadline - time.monotonic())

            try:
                char = self._output_queue.get(timeout=min(0.1, remaining))
            except queue.Empty:
                continue

            output.append(char)

            # Only inspect the end of the output for the CDB prompt.
            tail = (tail + char)[-64:]

            if self._PROMPT_RE.search(tail):
                return "".join(output)

        raise DebuggerError("Timed out waiting for CDB prompt.\n" f"Partial output:\n{''.join(output)}")

    def command(
        self,
        command: str,
        timeout: float | None = None,
    ) -> str:

        self._send_raw(command.rstrip() + "\n")

        return self._read_until_prompt(timeout=timeout,)

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def continue_execution(self, timeout: float = 120.0,) -> str:

        return self.command("g", timeout=timeout,)

    def step_into(self) -> str:
        return self.command("t")

    # ------------------------------------------------------------------
    # Registers
    # ------------------------------------------------------------------

    def get_register(self, name: str,) -> int:

        output = self.command(f"r {name}")

        wanted = name.lower()

        for register, value in self._REGISTER_RE.findall(output):
            if register.lower() == wanted:
                return self._parse_address(value)

        raise DebuggerError(f"Could not parse register " f"{name!r}:\n{output}")

    def get_registers(
        self,
        *names: str,
    ) -> dict[str, int]:

        if not names:
            raise ValueError("At least one register is required")

        return {
            name.lower(): self.get_register(name)
            for name in names
        }

    # ------------------------------------------------------------------
    # Modules
    # ------------------------------------------------------------------

    def get_module(self, module_name: str,) -> ModuleInfo:

        stem = Path(module_name).stem

        output = self.command(f"lm m {stem}")

        for match in self._MODULE_RE.finditer(output):
            start, end, name = match.groups()

            if name.lower() == stem.lower():
                return ModuleInfo(
                    name=name,
                    base=self._parse_address(start),
                    end=self._parse_address(end),
                )

        raise DebuggerError(f"Could not locate module " f"{module_name!r}:\n" f"{output}")

    def get_modules(self,) -> tuple[ModuleInfo, ...]:
        '''
        Return all modules currently loaded in the debuggee.
        '''

        output = self.command("lm")

        modules: list[ModuleInfo] = []

        for match in self._MODULE_RE.finditer(output):
            start, end, name = match.groups()

            modules.append(
                ModuleInfo(
                    name=name,
                    base=self._parse_address(start),
                    end=self._parse_address(end),
                )
            )

        if not modules:
            raise DebuggerError("Could not parse loaded modules:\n" f"{output}")

        return tuple(modules)

    # ------------------------------------------------------------------
    # Breakpoints
    # ------------------------------------------------------------------

    def set_breakpoint(self, address: int,) -> None:

        self.command(f"bp 0x{address:x}")

    def set_access_breakpoint(
        self,
        address: int,
        size: int = 8,
    ) -> None:

        if size not in (1,2,4,8):
            raise ValueError("Hardware breakpoint size must be " "1, 2, 4, or 8")

        if address % size != 0:
            raise ValueError(f"Address 0x{address:x} is not " f"{size}-byte aligned")

        # r = break on read OR write access.
        self.command(f"ba r{size} 0x{address:x}")

    def list_breakpoints(self) -> str:
        return self.command("bl")

    def clear_all_breakpoints(self) -> None:
        self.command("bc *")

    # ------------------------------------------------------------------
    # Memory
    # ------------------------------------------------------------------

    def read_qword(self, address: int,) -> int:

        output = self.command(f"dq 0x{address:x} L1")

        # Typical:
        #
        # 00000091`5555fb90  00000000`00000000
        pattern = re.compile(r"^\s*[0-9a-fA-F`]+\s+" r"([0-9a-fA-F`]+)", re.MULTILINE,)

        match = pattern.search(output)

        if match is None:
            raise DebuggerError(f"Could not read qword at " f"0x{address:x}:\n" f"{output}")

        return self._parse_address(match.group(1))

    def read_qwords(
        self,
        address: int,
        count: int,
    ) -> tuple[int, ...]:

        if count <= 0:
            raise ValueError("count must be positive")

        output = self.command(f"dq 0x{address:x} L0n{count}")

        values: list[int] = []

        line_pattern = re.compile(r"^\s*[0-9a-fA-F`]+\s+(.*)$")

        value_pattern = re.compile(r"\b[0-9a-fA-F]{8}`[0-9a-fA-F]{8}\b")

        for line in output.splitlines():
            line_match = line_pattern.match(line)

            if line_match is None:
                continue

            data_text = line_match.group(1)

            for value_text in value_pattern.findall(data_text):
                values.append(self._parse_address(value_text))

        if len(values) < count:
            raise DebuggerError(
                f"Expected {count} qwords from "
                f"0x{address:x}, but parsed "
                f"{len(values)}:\n{output}"
            )

        return tuple(values[:count])

    def write_memory(
        self,
        output_path: Path | str,
        start_va: int,
        end_va: int,
    ) -> Path:

        output_path = Path(output_path).resolve()

        if end_va <= start_va:
            raise ValueError("end_va must be greater than start_va")

        output_path.parent.mkdir(parents=True, exist_ok=True,)

        if output_path.exists():
            output_path.unlink()

        temp_name = f"{output_path.stem}_cdb_tmp.bin"
        temp_path = Path.cwd() / temp_name

        if temp_path.exists():
            temp_path.unlink()

        command = (f".writemem {temp_name} " f"0x{start_va:X} " f"0x{end_va - 1:X}")

        print(f"[debug] CDB dump command: {command}")

        output = self.command(command, timeout=120.0,)

        if not temp_path.exists():
            raise DebuggerError("CDB did not create temporary memory dump " f"{temp_path}:\n{output}")

        temp_path.replace(output_path)

        return output_path

    # ------------------------------------------------------------------
    # Disassembly
    # ------------------------------------------------------------------

    def disassemble_one(self, address: int) -> Instruction:
        '''
        1. Verify that CDB returned a valid instruction.
        2. Verify that the decoded address matches the requested address.
        3. Reject zero-length instructions and undecodable placeholders.
        4. Independently read the instruction bytes from memory and compare them against CDB's disassembly.
        '''
        output = self.command(f"u 0x{address:x} L1")
        instruction = self._parse_first_instruction(output)

        if instruction is None:
            raise DebuggerError(f"Could not disassemble 0x{address:x}:\n{output}")

        if instruction.address != address:
            raise DebuggerError(f"Address mismatch: expected 0x{address:x}, got 0x{instruction.address:x}")

        if not 1 <= instruction.size <= 15:
            raise DebuggerError(f"Invalid instruction length {instruction.size} at 0x{address:x}")

        actual = self.read_instruction_bytes(address, instruction.size)

        if actual != instruction.raw_bytes:
            raise DebuggerError(
                f"Instruction bytes mismatch at 0x{address:x}: "
                f"disassembly={instruction.raw_bytes.hex()}, memory={actual.hex()}"
            )

        return instruction

    def read_instruction_bytes(self, address: int, size: int) -> bytes:
        '''
        Raw memory verification method
        Ensures instruction bytes returned by CDB match the actual bytes in memory. 
        '''
        if not 1 <= size <= 15:
            raise ValueError(f"Invalid x64 instruction size: {size}")

        output = self.command(f"db 0x{address:x} L0n{size}")
        pattern = re.compile(r"^\s*[0-9a-fA-F`]+\s+((?:[0-9a-fA-F]{2}[\s-]*)+)", re.MULTILINE)

        data = b"".join(bytes.fromhex(m.group(1).replace("-", "")) for m in pattern.finditer(output))

        if len(data) != size:
            raise DebuggerError(f"Expected {size} bytes at 0x{address:x}, received {len(data)}:\n{output}")

        return data

    def disassemble_previous(self, address: int,) -> Instruction:

        output = self.command(f"ub 0x{address:x} L1")

        instructions = (self._parse_instructions(output))

        if not instructions:
            raise DebuggerError(f"Could not disassemble before " f"0x{address:x}:\n" f"{output}")

        return instructions[-1]

    def iter_instructions(
        self,
        address: int,
        max_instructions: int = 16,
    ) -> Iterator[Instruction]:

        current = address

        for _ in range(max_instructions):
            instruction = (self.disassemble_one(current))

            yield instruction

            if instruction.size == 0:
                raise DebuggerError(f"Zero-length instruction at " f"0x{instruction.address:x}")

            current += instruction.size

    # ------------------------------------------------------------------
    # Relative direct JMP decoding
    # ------------------------------------------------------------------

    @staticmethod
    def resolve_direct_jump(instruction: Instruction,) -> DirectJump | None:

        raw = instruction.raw_bytes

        if not raw:
            return None

        # JMP rel32
        #
        # E9 xx xx xx xx
        if (raw[0] == 0xE9 and len(raw) >= 5):
            displacement = struct.unpack("<i", raw[1:5],)[0]

            target = (instruction.address + 5 + displacement)

            return DirectJump(
                source=instruction.address,
                target=target,
                size=5,
            )

        # JMP rel8
        #
        # EB xx
        if (raw[0] == 0xEB and len(raw) >= 2):
            displacement = struct.unpack("<b", raw[1:2],)[0]

            target = (instruction.address + 2 + displacement)

            return DirectJump(
                source=instruction.address,
                target=target,
                size=2,
            )

        return None

    # ------------------------------------------------------------------
    # Parsing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_address(value: str,) -> int:

        return int(value.replace("`", "",), 16,)

    def _parse_first_instruction(self, output: str,) -> Instruction | None:

        instructions = (self._parse_instructions(output))

        if not instructions:
            return None

        return instructions[0]

    def _parse_instructions(self, output: str,) -> list[Instruction]:

        instructions: list[ Instruction ] = []

        for line in output.splitlines():
            match = self._DISASM_RE.match(line)

            if match is None:
                continue

            (
                address_text,
                bytes_text,
                mnemonic,
                operands,
            ) = match.groups()

            # Must be an even-length hex byte string.
            if len(bytes_text) % 2 != 0:
                continue

            try:
                raw_bytes = bytes.fromhex(bytes_text)

            except ValueError:
                continue

            instructions.append(
                Instruction(
                    address=self._parse_address(address_text),
                    raw_bytes=raw_bytes,
                    mnemonic=mnemonic.lower(),
                    operands=(operands or "").strip(),
                    text=line.strip(),
                )
            )

        return instructions

    def get_process_id(self) -> int:
        '''
        Return the PID of the current debuggee process.
        '''


        output = self.command("|")

        # Typical CDB output contains something like:
        #
        # .  0    id: 1a2c    create  name: sample.exe
        #
        pattern = re.compile(r"^\s*[\.\#]?\s*\d+\s+" r"id:\s*([0-9a-fA-F]+)", re.MULTILINE,)

        match = pattern.search(output)

        if match is None:
            raise DebuggerError("Could not determine debuggee PID:\n" f"{output}")

        return int(match.group(1), 16,)
